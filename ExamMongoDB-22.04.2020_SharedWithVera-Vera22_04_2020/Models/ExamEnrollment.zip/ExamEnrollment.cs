﻿
using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using System;
using System.Collections.Generic;

namespace ExamMongoDB.Models
{
    public class ExamEnrollment // i copied these attributes to Exam and maybe we do not need this class
    {
        public string SubjectCode { get; set; }
        public string SubjectName { get; set; }

        public DateTime ExamDate { get; set; }
        public string RoomId { get; set; }
        public string Mark { get; set; }

        public List<Programme> Programme { get; set; } // when i use this code, it is not possible to find  Programme.ProgrammeName in index.cshtml
    }
}