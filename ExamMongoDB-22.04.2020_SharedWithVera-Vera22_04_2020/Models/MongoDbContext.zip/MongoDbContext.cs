﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using ExamMongoDB.Identity;
using ExamMongoDB.Models;
using MongoDB.Driver;

namespace ExamMongoDB.Models
{
    
        public class MongoDbContext
        {
            private readonly IMongoDatabase _mongoDb;
            public MongoDbContext()
        //{
        //    var client = new MongoClient("mongodb+srv://db-admin:AdminPassword@cluster0-aezp7.azure.mongodb.net/test?retryWrites=true&w=majority");
        //    _mongoDb = client.GetDatabase("ExamTool");
        //}

        //// local MongoDB server
            {
                var client = new MongoClient();
                _mongoDb = client.GetDatabase("ExamTool");
            }

        //public IMongoCollection<ExamEnrollment> ExamEnrollment
        //{
        //    get
        //    {

        //        return _mongoDb.GetCollection<ExamEnrollment>("ExamEnrollment");

        //    }
        //}

        //public IMongoCollection<Programme> Programme
        //    {
        //            get
        //            {
        //                return _mongoDb.GetCollection<Programme>("programme");   // change to correct collection name

        //            }
        //    }
        //public IMongoCollection<Exam> Exam
        //{
        //    get
        //    {

        //        return _mongoDb.GetCollection<Exam>("exam");

        //    }
        //}

        //public IMongoCollection<Student> Student
        //{
        //    get
        //    {

        //        return _mongoDb.GetCollection<Student>("student");

        //    }
        //}
    }
 }