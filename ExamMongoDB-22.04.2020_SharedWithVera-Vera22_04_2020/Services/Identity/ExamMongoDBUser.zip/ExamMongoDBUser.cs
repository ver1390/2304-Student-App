﻿using AspNetCore.Identity.Mongo.Model;
using ExamMongoDB.Models;
using MongoDB.Bson.Serialization.Attributes;
using System.Collections.Generic;

namespace ExamMongoDB.Identity
{
    public class ExamMongoDBUser : MongoUser
    {
     
            public ExamMongoDBUser()
            {
                //ExamEnrollments = new ExamEnrollment(); //// this code create ExamEnrollment  {} includes all attributes from ExamEnrollment class 
                Programmes = new Programme();
                ExamEnrollment = new List<ExamEnrollment>();
            }

            //[BsonElement("programme")]
            //[Required]
            public Programme Programmes { get; set; }


            [BsonElement("ExamEnrollment")]
            //[Required]
            // public List<ExamEnrollment> ExamEnrollment { get; set; } = new List<ExamEnrollment>(); // this code create emptry ExamEnrollment []
            public List<ExamEnrollment> ExamEnrollment { get; set; } // this code create emptry ExamEnrollment []




            //[BsonElement("fname")]
            public string Fname { get; set; }

            //[BsonElement("lname")]
            public string Lname { get; set; }

            //public ExamEnrollment ExamEnrollments { get; set; } // this code create ExamEnrollment  {} includes all attributes from ExamEnrollment class 


     
    }
}
